# KOC API 挖掘工具包

用 YouTube Data API v3 批量挖韩国小体量创作者（KOC）并自动打分、排查、出表。
零第三方依赖，Python 3.7+ 直接跑，不用 pip 装东西。

## 快速开始

1. 填密钥：双击 `setup_api_key.command`（或手动把密钥写进 `api_key.txt`）。
   没有密钥：console.cloud.google.com → 启用 YouTube Data API v3 → 创建 API 密钥。
2. 跑流程：双击 `run_game_line.command`（游戏类）或 `run_film_line.command`（影视类）。
3. 看结果：`scripts/` 下生成的 `.html`（浏览器打开）和 `.csv`。

也可以只设环境变量，不建文件：`export YOUTUBE_API_KEY=你的密钥`

完整图文说明见 `START_HERE.html`。

## 目录

```
START_HERE.html            使用说明（双击打开）
README.md                  本文件
setup_api_key.command      一键配置并校验密钥
run_game_line.command      游戏线全流程
run_film_line.command      影视线全流程
api_key.txt                放你的密钥（当前是占位内容）
scripts/                   全部脚本
sample_output/             2026-10 的两张真实成果表，格式参考
```

## 两条线

| 线 | 终点 | 关键判据 |
|---|---|---|
| 游戏类 | 转化成某款游戏的玩家 | 平台对不对（PC/主机 vs 手游）、玩法对不对（生存建造/开放世界/沙漠废土）、攻略型优先于实况型 |
| 影视类 | 转化成某部电影的购票观众 | 是不是真电影号、决策影响力（推荐/解说/榜单）、科幻史诗调性、剧透解说 vs 前瞻分析 |

## 游戏线

```bash
cd scripts
python3 find_dune_game_koc2.py                              # 召回 -> dg2_s1.json / dg2_s2.json
python3 dg2_s3_score.py                                     # 打分 -> dg2_s3_scored.json
python3 pick_top.py dg2_s3_scored.json dg2_picks.json 40 30 # 挑前 40 名
python3 dg2_s4_contacts.py dg2_picks.json dg2_s4.json       # 排查 + 联系方式 -> dg2_s4.json
python3 check_vertical.py                                   # 垂直度 -> vertical_check.json
python3 make_table_auto.py dg2_s4.json 游戏类 我的游戏线KOC  # 出表
```

转化分 = 生存建造占比 45 + 攻略/百科占比 20 + 沙漠废土占比 15 + PC/主机占比 20，
手游占比 > 25% 扣 25 分。

## 影视线

```bash
cd scripts
python3 df1_find_movie_koc.py    # 第一轮召回
python3 df1_s3_score.py          # 第一轮打分
python3 df2_round2.py            # 第二轮扩召回 + 打分
python3 df_active_scan.py        # 活跃度快筛（近 120 天）-> df_alive.json
python3 pick_top.py df_alive.json df_picks.json 30
python3 df_s4_contacts.py df_picks_a.json df_s4.json    # 分批跑
python3 df_s4_contacts.py df_picks_b.json df_s4b.json
python3 df_theater.py            # 影院向 vs OTT 向 -> df_final16.json
python3 make_table_auto.py df_final16.json 影评类 我的影视线KOC
```

`df_theater.py` 需要 `df_s4.json` 和 `df_s4b.json` 同时存在。

## 硬标准

订阅 1000～50000，韩国（`country == KR`），内容相关，播放量真实。上限 5 万是铁律。

## 已知坑

- 韩国频道标题常不写游戏名，占比类指标会失真，必须人工核「未识别」标题原文。
- 播放量高不等于能转化：低龄向沙盒号、童话寓言解说号、网飞剧集号均播很高但完全不对口。
- 出表前必核活跃度，只看内容分会混进停更号。
- 联系方式按序查：频道简介 → 全量视频简介 → Telegram / 开放聊天室。只查频道简介会漏约三分之一。
- YouTube 官方「含付费推广」徽章抓不到，判断商单经验改看创作者自披露的 광고/협찬/PPL/제휴。

## 排除池

`scripts/exclude_pool_raw.json` 是历史已审频道（约 3600 个），用于避免重复推人。
从零开始就把它换成 `exclude_pool_empty.json`（改名为 `exclude_pool_raw.json`）。

## 两个旧脚本

`dg2_make_table.py` / `df_make_table.py` 硬编码了 2026-10 那批成果的人工判断，
只能复现旧表。新数据用 `make_table_auto.py`。

## 输出表列格式

分类 / 用户名 / 平台 / 平台链接 / 粉丝量 / 视频内容类型 / 均播 / 活跃度 / 邮箱 / 推荐理由 / 备注

视频内容类型按四段写：类型、平台占比（游戏线）或形态占比（影视线）、受众、视频风格。
推荐理由与备注由 `make_table_auto.py` 留空，需人工补。

打包时间：2026-10-29
