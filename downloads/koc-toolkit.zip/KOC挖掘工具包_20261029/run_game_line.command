#!/bin/bash
cd "$(dirname "$0")/scripts" || exit 1
echo "=============================================="
echo " 游戏类 KOC 全流程（约 6 步，耗时看候选数量）"
echo "=============================================="
if ! command -v python3 >/dev/null 2>&1; then
  echo "[错误] 没找到 python3，请先安装 Python 3"
  read -r -p "按回车退出..."; exit 1
fi
if [ ! -f ../api_key.txt ] || grep -q "PASTE_YOUR" ../api_key.txt 2>/dev/null; then
  echo "[错误] 还没配置 API 密钥，请先双击 setup_api_key.command"
  read -r -p "按回车退出..."; exit 1
fi

echo ""
echo "[1/6] 召回候选频道（搜词 -> 去重 -> 拉频道画像）"
python3 find_dune_game_koc2.py || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "[2/6] 转化潜力打分（平台/玩法/攻略占比）"
python3 dg2_s3_score.py || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "[3/6] 挑出前 40 名（分数 >= 30）"
python3 pick_top.py dg2_s3_scored.json dg2_picks.json 40 30 || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "[4/6] 逐频道排查目标 IP 内容 + 抓联系方式 + 均播活跃度（最费配额的一步）"
python3 dg2_s4_contacts.py dg2_picks.json dg2_s4.json || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "[5/6] 单游戏垂直度检查（观众跟游戏走还是跟人走）"
python3 check_vertical.py || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "[6/6] 生成 HTML 表 + CSV"
python3 make_table_auto.py dg2_s4.json 游戏类 我的游戏线KOC || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "=============================================="
echo " 完成。成果在 scripts/ 目录："
echo "   我的游戏线KOC.html  （双击用浏览器打开）"
echo "   我的游戏线KOC.csv"
echo " 中间数据：dg2_s3_scored.json / dg2_s4.json / vertical_check.json"
echo ""
echo " 别忘了人工做两件事："
echo "   1) 填推荐理由和备注（脚本留空了）"
echo "   2) 核活跃度，剔掉停更号"
echo "=============================================="
open . 2>/dev/null
read -r -p "按回车退出..."
