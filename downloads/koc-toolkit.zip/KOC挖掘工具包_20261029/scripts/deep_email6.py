# -*- coding: utf-8 -*-
"""对 6 个仍无联系方式的频道做深挖：全量简介任意邮箱 + about 页 HTML + 视频里任意外链。"""
import json, re, time, urllib.parse, urllib.request

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
MAIL = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')
UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36'


def api(path, params, retry=3):
    params = dict(params); params['key'] = API_KEY
    url = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try:
            return json.load(urllib.request.urlopen(url, timeout=30))
        except Exception as e:
            if i == retry - 1: return {'_err': str(e)}
            time.sleep(2)


def get(url):
    req = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept-Language': 'ko,en'})
    return urllib.request.urlopen(req, timeout=30).read().decode('utf-8', 'ignore')


ev = {c['title']: c for c in json.load(open('nondune_final14.json', encoding='utf-8'))}
SIX = ['아이무비', '무비두잔', '킹무비', '씨쿠무비', '라반', '스피리투스']
out = {}
for name in SIX:
    c = ev[name]
    print('=' * 78); print(name, '| subs', c['subs'], '| customUrl', c.get('customUrl'), '| desc长度', len(c.get('desc') or ''))
    print('--- 频道简介全文 ---'); print((c.get('desc') or '(空)')[:600])

    # 1) 全量视频简介：任何邮箱 / 任何外链
    d = api('channels', {'part': 'contentDetails', 'id': c['cid']})
    pl = d['items'][0]['contentDetails']['relatedPlaylists']['uploads']
    ids, tok = [], None
    while len(ids) < 400:
        p = {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 50}
        if tok: p['pageToken'] = tok
        r = api('playlistItems', p)
        if r.get('_err'): break
        ids += [x['contentDetails']['videoId'] for x in r.get('items', [])]
        tok = r.get('nextPageToken')
        if not tok: break
    mails, urls, n = {}, {}, 0
    for i in range(0, len(ids), 50):
        r = api('videos', {'part': 'snippet', 'id': ','.join(ids[i:i + 50])})
        for x in r.get('items', []):
            n += 1
            ds = x['snippet'].get('description') or ''
            for m in MAIL.finditer(ds):
                mails.setdefault(m.group(0).lower(), 0)
                mails[m.group(0).lower()] += 1
            for u in re.findall(r'https?://[^\s|)"\']+', ds):
                dom = urllib.parse.urlparse(u).netloc.lower().replace('www.', '')
                urls[dom] = urls.get(dom, 0) + 1
    print('--- 视频简介扫描 %d 条 ---' % n)
    print('   邮箱(无条件):', dict(sorted(mails.items(), key=lambda x: -x[1])[:6]) or '无')
    top = sorted(urls.items(), key=lambda x: -x[1])[:8]
    print('   高频外链:', top or '无')

    # 2) about 页 HTML
    ab = ''
    handle = c.get('customUrl') or ''
    for u in ['https://www.youtube.com/%s/about' % handle.lstrip('@') if handle.startswith('@') else '',
              'https://www.youtube.com/channel/%s/about' % c['cid']]:
        if not u: continue
        try:
            ab = get(u); break
        except Exception as e:
            ab = 'ERR:%s' % e
    mails_html = sorted({m.group(0).lower() for m in MAIL.finditer(ab)})
    links_html = sorted({u for u in re.findall(r'"url":"(https?://[^"]+)"', ab)
                         if 'youtube.com' not in u and 'google' not in u})
    print('--- about 页 ---')
    print('   邮箱:', mails_html[:6] or '无')
    print('   外链:', links_html[:8] or '无')
    out[name] = {'scanned': n, 'mails': mails, 'urls': dict(sorted(urls.items(), key=lambda x: -x[1])[:10]),
                 'about_mails': mails_html[:6], 'about_links': links_html[:8], 'desc': c.get('desc') or ''}
json.dump(out, open('nondune_email_deep6.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('\n已写入 nondune_email_deep6.json')
