# -*- coding: utf-8 -*-
"""对 9 个没找到邮箱的频道：扫视频简介找邮箱/联系方式（带商务上下文才算数）。"""
import json, re, time, urllib.parse, urllib.request

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
MAIL = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')
BIZ_CTX = re.compile(r'문의|협업|광고|비즈니스|business|contact|제휴|sponsor|유료', re.I)
TG = re.compile(r'(?:t\.me|telegram\.me)/[A-Za-z0-9_]+')
OPENKAKAO = re.compile(r'open\.kakao\.com/[A-Za-z0-9]+')
KAKAO = re.compile(r'pf\.kakao\.com/[A-Za-z0-9]+')


def api(path, params, retry=3):
    params = dict(params); params['key'] = API_KEY
    url = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try:
            return json.load(urllib.request.urlopen(url, timeout=30))
        except Exception as e:
            if i == retry - 1:
                return {'_err': str(e)}
            time.sleep(2)


def scan(cid, cap=300):
    d = api('channels', {'part': 'contentDetails', 'id': cid})
    pl = d['items'][0]['contentDetails']['relatedPlaylists']['uploads']
    ids, tok = [], None
    while len(ids) < cap:
        p = {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 50}
        if tok: p['pageToken'] = tok
        r = api('playlistItems', p)
        if r.get('_err'): break
        ids += [x['contentDetails']['videoId'] for x in r.get('items', [])]
        tok = r.get('nextPageToken')
        if not tok: break
    hits, n = {}, 0
    for i in range(0, len(ids), 50):
        r = api('videos', {'part': 'snippet', 'id': ','.join(ids[i:i + 50])})
        for x in r.get('items', []):
            n += 1
            desc = x['snippet'].get('description') or ''
            for mm in MAIL.finditer(desc):
                ctx = desc[max(0, mm.start() - 70):mm.end() + 30]
                if BIZ_CTX.search(ctx):
                    hits.setdefault(mm.group(0).lower(), []).append(ctx)
            for pat, key in ((TG, 'telegram'), (OPENKAKAO, 'openkakao'), (KAKAO, 'kakao채널')):
                m2 = pat.search(desc)
                if m2 and BIZ_CTX.search(desc[max(0, m2.start() - 70):m2.end() + 30]):
                    hits.setdefault(key + ':' + m2.group(0), []).append(desc[max(0, m2.start() - 70):m2.end() + 30])
    return n, hits


ev = {c['title']: c for c in json.load(open('nondune_final14.json', encoding='utf-8'))}
MISSING = ['아이무비', '무비두잔', '제이슨 무비 : Jason Movie', '킹무비', '씨쿠무비',
           '파란 모닥불 [생존게임 위키 채널]', '라반', '투투 TuTU', '스피리투스']
def scan_any(text):
    """在任意文本里找所有联系方式（邮箱 / TG / 公开聊天 / 卡카오频道）。"""
    h = {}
    for mm in MAIL.finditer(text):
        ctx = text[max(0, mm.start() - 70):mm.end() + 30]
        if BIZ_CTX.search(ctx):
            h.setdefault(mm.group(0).lower(), []).append(ctx)
    for pat, key in ((TG, 'telegram'), (OPENKAKAO, '오픈카톡'), (KAKAO, '카카오채널')):
        m2 = pat.search(text)
        if m2 and BIZ_CTX.search(text[max(0, m2.start() - 70):m2.end() + 30]):
            h.setdefault(key + ':' + m2.group(0), []).append(text[max(0, m2.start() - 70):m2.end() + 30])
    return h


out = {}
for name in MISSING:
    cd = ev[name].get('desc') or ''
    ch_hits = scan_any(cd)
    n, hits = scan(ev[name]['cid'])
    out[name] = {'scanned': n, 'hits': {k: v[0] for k, v in list(hits.items())[:4]},
                 'n_hits': sum(len(v) for v in hits.values()),
                 'chan_desc': cd[:300], 'chan_contact': {k: v[0] for k, v in ch_hits.items()}}
    print('=' * 74)
    print(name, '| 扫描视频', n, '| 视频简介命中', len(hits), '| 频道简介命中', len(ch_hits))
    for k, v in ch_hits.items():
        print('   (频道简介) [%s]  %s' % (k, re.sub(r'\s+', ' ', v[0])[:110]))
    for k, v in list(hits.items())[:4]:
        ctx = v[0] if isinstance(v, list) else v
        print('   [%s] x%d  %s' % (k, len(v) if isinstance(v, list) else 1,
                                   re.sub(r'\s+', ' ', ctx)[:110]))
    if not hits:
        print('   —— 视频简介里也没有商务联系方式')
json.dump(out, open('nondune_email_rescan.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('\n已写入 nondune_email_rescan.json')
