# -*- coding: utf-8 -*-
"""沙丘影评线 KOC：排除所有历史频道，按「转化为沙丘 3 电影观众」召回。"""
import json, re, time, urllib.parse, urllib.request

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
EX = json.load(open('exclude_pool_raw.json', encoding='utf-8'))
EX_IDS, EX_T = set(EX['ids']), set(EX['titles'])

# A 真人找片会打的词
DECIDE = ['영화 추천', '재밌는 영화', '볼만한 영화', '넷플릭스 영화 추천', '영화 리뷰',
          '영화 결말 해석', '개봉 영화 추천', '인생 영화', '영화 순위', '극장에서 볼 영화']
# B 盘点/必看/科幻
LIST = ['명작 영화 추천', '꼭 봐야 할 영화', '영화 top10', 'SF 영화 추천', '우주 영화 추천',
        '디스토피아 영화', '블록버스터 영화', '세계관 영화']
# C 沙丘调性锚点片（SF 史诗 / 沙漠 / 政治）
ANCHOR = ['인터스텔라 해석', '블레이드 러너 2049', '매드맥스 분노의 도로', '스타워즈 영화',
          '아바타 리뷰', '레디 플레이어 원', '매트릭스 해석', '프로메테우스 해석',
          '컨택트 영화', '오펜하이머 리뷰', '테넷 해석', '왕좌의 게임 해석']
SHORTS = ['영화 추천', 'SF 영화 추천', '명작 영화 추천', '결말 포함 영화', '넷플릭스 영화 추천']
WORDS = DECIDE + LIST + ANCHOR


def api(path, params, retry=4):
    params = dict(params); params['key'] = API_KEY
    url = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try:
            return json.load(urllib.request.urlopen(url, timeout=30))
        except Exception as e:
            if i == retry - 1: return {'_err': str(e)}
            time.sleep(2)


chans = {}
def recall(words, shorts=False):
    for w in words:
        p = {'part': 'snippet', 'type': 'video', 'q': w, 'maxResults': 50,
             'regionCode': 'KR', 'relevanceLanguage': 'ko'}
        if shorts: p['videoDuration'] = 'short'
        r = api('search', p)
        if r.get('_err'): print('  !! %s -> %s' % (w, r['_err'][:60])); continue
        g = 0
        for x in r.get('items', []):
            cid = x['snippet']['channelId']
            if cid in EX_IDS or x['snippet']['channelTitle'] in EX_T: continue
            c = chans.setdefault(cid, {'cid': cid, 'title': x['snippet']['channelTitle'], 'qs': []})
            if w not in c['qs']: c['qs'].append(w); g += 1
        print('  %-26s 新 %d' % (w, g))

print('=== 常规召回 %d 词 ===' % len(WORDS)); recall(WORDS)
print('=== Shorts 池 %d 词 ===' % len(SHORTS)); recall(SHORTS, shorts=True)
json.dump(list(chans.values()), open('df1_s1.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('\nS1 去重后新频道 %d 个' % len(chans))

ids = list(chans.keys())
prof = []
for i in range(0, len(ids), 50):
    r = api('channels', {'part': 'snippet,statistics', 'id': ','.join(ids[i:i+50])})
    for x in r.get('items', []):
        s, st = x['snippet'], x['statistics']
        subs = 0 if st.get('hiddenSubscriberCount') else int(st.get('subscriberCount', 0) or 0)
        c = chans[x['id']]
        c.update({'subs': subs, 'country': s.get('country') or '', 'customUrl': s.get('customUrl') or '',
                  'desc': s.get('description') or '', 'videos': int(st.get('videoCount', 0) or 0)})
        if c['country'] == 'KR' and 1000 <= subs <= 50000: prof.append(c)
json.dump(prof, open('df1_s2.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('S2 韩国 + 1k~5w 订阅：%d 个' % len(prof))
