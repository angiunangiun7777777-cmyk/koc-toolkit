# -*- coding: utf-8 -*-
"""S4：对入围频道做 ① 主页 q=듄 复核 ② 三来源找联系方式 ③ 拉活跃度与均播。"""
import json, re, time, urllib.parse, urllib.request, sys, datetime

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
MAIL = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')
BIZ = re.compile(r'문의|협업|광고|비즈니스|business|contact|제휴|sponsor|유료', re.I)
TG = re.compile(r'(?:t\.me|telegram\.me)/[A-Za-z0-9_]+')
OPENK = re.compile(r'open\.kakao\.com/[A-Za-z0-9]+')
KAKAO = re.compile(r'pf\.kakao\.com/[A-Za-z0-9]+')


def api(path, params, retry=4):
    params = dict(params); params['key'] = API_KEY
    url = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try:
            return json.load(urllib.request.urlopen(url, timeout=30))
        except Exception as e:
            if i == retry - 1:
                return {'_err': str(e)}
            time.sleep(2)


def contacts(text):
    h = {}
    for m in MAIL.finditer(text):
        ctx = text[max(0, m.start() - 70):m.end() + 30]
        if BIZ.search(ctx):
            h.setdefault(m.group(0).lower(), []).append(ctx)
    for pat, key in ((TG, 'telegram'), (OPENK, '오픈카톡'), (KAKAO, '카카오채널')):
        m2 = pat.search(text)
        if m2 and BIZ.search(text[max(0, m2.start() - 70):m2.end() + 30]):
            h.setdefault(key + ':' + m2.group(0), []).append(text[max(0, m2.start() - 70):m2.end() + 30])
    return h


picks = json.load(open(sys.argv[1], encoding='utf-8'))
out = []
for c in picks:
    # ① 主页 q=듄
    r = api('search', {'part': 'snippet', 'type': 'video', 'channelId': c['cid'],
                       'q': '듄', 'maxResults': 20})
    q_hit = [x['snippet']['title'] for x in r.get('items', [])] if not r.get('_err') else []

    # ② 联系方式：频道简介 -> 全量视频简介
    ch_hits = contacts(c.get('desc') or '')
    pl = api('channels', {'part': 'contentDetails', 'id': c['cid']})['items'][0][
        'contentDetails']['relatedPlaylists']['uploads']
    ids, tok = [], None
    while len(ids) < 300:
        p = {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 50}
        if tok:
            p['pageToken'] = tok
        rr = api('playlistItems', p)
        if rr.get('_err'):
            break
        ids += [x['contentDetails']['videoId'] for x in rr.get('items', [])]
        tok = rr.get('nextPageToken')
        if not tok:
            break
    vh, dates, views = {}, [], []
    for i in range(0, len(ids), 50):
        rr = api('videos', {'part': 'snippet,statistics', 'id': ','.join(ids[i:i + 50])})
        for x in rr.get('items', []):
            d = x['snippet'].get('description') or ''
            for k, v in contacts(d).items():
                vh.setdefault(k, []).extend(v)
            dates.append(x['snippet']['publishedAt'][:10])
            views.append(int(x['statistics'].get('viewCount', 0) or 0))
    recent = [d for d in dates if d >= str(datetime.date.today() - datetime.timedelta(days=90))]
    last = max(dates) if dates else ''
    vh_sorted = sorted(vh.items(), key=lambda x: -len(x[1]))
    c.update({'q_dune_hit': q_hit, 'chan_contact': {k: v[0] for k, v in ch_hits.items()},
              'video_contact': {k: v[0] for k, v in vh_sorted[:5]},
              'video_contact_n': {k: len(v) for k, v in vh_sorted[:5]},
              'total_scanned': len(ids), 'last': last, 'recent90': len(recent),
              'mean': int(sum(views) / len(views)) if views else 0})
    out.append(c)
    print('=' * 76)
    print('%-34s subs %-7s 分%.0f' % (c['title'][:34], c['subs'], c['score']))
    print('  主页 q=듄 命中 %d | 标题扫描沙丘命中 %d | 最近 %s | 90天 %d 条 | 均播 %d' % (
        len(q_hit), c.get('n_dune', 0), last, len(recent), c['mean']))
    print('  频道简介联系:', list(ch_hits.keys()) or '无')
    print('  视频简介联系:', vh_sorted[:3] or '无')
OUTF = sys.argv[2] if len(sys.argv) > 2 else 'dg2_s4.json'
json.dump(out, open(OUTF, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('\n已写入 %s，共 %d 个' % (OUTF, len(out)))
