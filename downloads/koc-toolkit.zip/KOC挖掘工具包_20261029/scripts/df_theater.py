# -*- coding: utf-8 -*-
"""影评线最后一块：影院向 vs OTT 向占比 —— 直接对应「会不会买票」这个转化终点。"""
import json, re, time, urllib.parse, urllib.request

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
THEATER = re.compile(r'극장|개봉|예매|아이맥스|IMAX|상영|스크린|박스오피스|흥행|4DX|재개봉', re.I)
OTT = re.compile(r'넷플릭스|넷플|왓챠|쿠팡플레이|티빙|디즈니|웨이브|OTT|시리즈|드라마|시즌', re.I)

def api(path, params, retry=3):
    params = dict(params); params['key'] = API_KEY
    u = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try: return json.load(urllib.request.urlopen(u, timeout=25))
        except Exception as e:
            if i == retry-1: return {'_err': str(e)}
            time.sleep(1.5)

a = json.load(open('df_s4.json', encoding='utf-8'))
b = json.load(open('df_s4b.json', encoding='utf-8'))
pool = {c['title']: c for c in a + b}
KEEP = ['미니필름(Mini Film)','똠냥이','디쿠무비','무비픽업','카페, 시네마','S펀지 무비[SPONGE MOVIE]',
        '지금여기','영화보리 Diogenes','비디오보는남자','무비토닉',
        '영화한잔?','좋은아내','이상한 장면 by 강병진','무비미슐랭','라라무비','무비영이']
out = []
for t in KEEP:
    c = pool[t]
    d = api('channels', {'part': 'contentDetails', 'id': c['cid']})
    pl = d['items'][0]['contentDetails']['relatedPlaylists']['uploads']
    ids, tok = [], None
    while len(ids) < 200:
        p = {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 50}
        if tok: p['pageToken'] = tok
        r = api('playlistItems', p)
        if r.get('_err'): break
        ids += [x['contentDetails']['videoId'] for x in r.get('items', [])]
        tok = r.get('nextPageToken')
        if not tok: break
    titles = []
    for i in range(0, len(ids), 50):
        r = api('videos', {'part': 'snippet', 'id': ','.join(ids[i:i+50])})
        for x in r.get('items', []): titles.append(x['snippet']['title'])
    n = len(titles) or 1
    th = sum(1 for x in titles if THEATER.search(x))
    ot = sum(1 for x in titles if OTT.search(x))
    c['theater_pct'] = round(th*100/n); c['ott_pct'] = round(ot*100/n)
    c['titles_all'] = titles[:200]
    out.append(c)
    print('%-28s 影院向 %3d%% ／ OTT向 %3d%%  (n=%d)' % (t[:28], c['theater_pct'], c['ott_pct'], n))
json.dump(out, open('df_final16.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('\n已写入 df_final16.json，共 %d 个' % len(out))
