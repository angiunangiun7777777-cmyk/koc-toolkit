# -*- coding: utf-8 -*-
"""对两轮所有 gate=1 且沙丘零命中的候选，只拉最近 1 条视频的日期，快筛活跃度。"""
import json, time, urllib.parse, urllib.request, datetime, sys

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
CUT = (datetime.date.today() - datetime.timedelta(days=120)).isoformat()


def api(path, params, retry=3):
    params = dict(params); params['key'] = API_KEY
    url = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try:
            return json.load(urllib.request.urlopen(url, timeout=25))
        except Exception as e:
            if i == retry - 1: return {'_err': str(e)}
            time.sleep(1.5)


pool = []
seen = set()
for f in ('df1_s3_scored.json', 'df2_s3.json'):
    for c in json.load(open(f, encoding='utf-8')):
        if c['cid'] in seen: continue
        if c['gate'] != 1 or c['n_dune'] != 0: continue
        if c['score'] < 20: continue
        seen.add(c['cid']); pool.append(c)
print('待快筛 %d 个（近 %s 之后有更新=活跃）' % (len(pool), CUT))

alive, dead = [], []
for c in pool:
    d = api('channels', {'part': 'contentDetails', 'id': c['cid']})
    if d.get('_err') or not d.get('items'): continue
    pl = d['items'][0]['contentDetails']['relatedPlaylists']['uploads']
    r = api('playlistItems', {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 5})
    if r.get('_err') or not r.get('items'): continue
    vid = [x['contentDetails']['videoId'] for x in r['items']]
    v = api('videos', {'part': 'snippet', 'id': ','.join(vid)})
    dates = sorted(x['snippet']['publishedAt'][:10] for x in v.get('items', []))
    if not dates: continue
    last = dates[-1]
    c['last'] = last
    if last >= CUT: alive.append(c)
    else: dead.append(c)
    print('  %-30s 最近 %s %s' % (c['title'][:30], last, '✓活跃' if last >= CUT else '✗停更'))

alive.sort(key=lambda x: -x['score'])
json.dump(alive, open('df_alive.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('\n活跃 %d / 停更 %d' % (len(alive), len(dead)))
print('--- 活跃清单（按转化分）---')
for c in alive:
    n = c['n_titles']
    print('  %-30s subs %-7s 分%.0f 电影%d%% 决策%d%% 榜单%d%% 科幻%d%% 均播%d 最近%s' % (
        c['title'][:30], c['subs'], c['score'], c['film']*100//n, c['decide']*100//n,
        c['list']*100//n, c['scifi']*100//n, c['mean'], c['last']))
