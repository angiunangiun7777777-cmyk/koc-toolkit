# -*- coding: utf-8 -*-
"""影评线 S4：主页 q=듄 复核 + 三来源找联系方式 + 活跃度 + 「결말포함」形态占比。"""
import json, re, time, urllib.parse, urllib.request, sys, datetime, statistics

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
MAIL = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')
BIZ = re.compile(r'문의|협업|광고|비즈니스|business|contact|제휴|sponsor|유료', re.I)
TG = re.compile(r'(?:t\.me|telegram\.me)/[A-Za-z0-9_]+')
OPENK = re.compile(r'open\.kakao\.com/[A-Za-z0-9]+')
KAKAO = re.compile(r'pf\.kakao\.com/[A-Za-z0-9]+')
# 形态判据
SPOIL = re.compile(r'결말\s*포함|결말포함|줄거리|몰아보기|요약|정주행|스토리', re.I)   # 看剧情
PREVIEW = re.compile(r'예고편|티저|개봉\s*예정|시사회|신작|분석|해석|세계관|비하인드|평점')  # 决定看不看
DUNE = re.compile(r'듄|dune|아라키스|메시아|스파이스\s*워즈|폴\s*아트레이데스|어웨이크닝', re.I)


def api(path, params, retry=4):
    params = dict(params); params['key'] = API_KEY
    url = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try:
            return json.load(urllib.request.urlopen(url, timeout=30))
        except Exception as e:
            if i == retry - 1: return {'_err': str(e)}
            time.sleep(2)


def contacts(text):
    h = {}
    for m in MAIL.finditer(text):
        ctx = text[max(0, m.start()-70):m.end()+30]
        if BIZ.search(ctx): h.setdefault(m.group(0).lower(), []).append(ctx)
    for pat, key in ((TG, 'telegram'), (OPENK, '오픈카톡'), (KAKAO, '카카오채널')):
        m2 = pat.search(text)
        if m2 and BIZ.search(text[max(0, m2.start()-70):m2.end()+30]):
            h.setdefault(key + ':' + m2.group(0), []).append(text[max(0, m2.start()-70):m2.end()+30])
    return h


picks = json.load(open(sys.argv[1], encoding='utf-8'))
out = []
for c in picks:
    r = api('search', {'part': 'snippet', 'type': 'video', 'channelId': c['cid'],
                       'q': '듄', 'maxResults': 20})
    q_hit = [x['snippet']['title'] for x in r.get('items', [])] if not r.get('_err') else []

    ch_hits = contacts(c.get('desc') or '')
    _cd = api('channels', {'part': 'contentDetails', 'id': c['cid']})
    pl = _cd['items'][0]['contentDetails']['relatedPlaylists']['uploads']
    ids, tok = [], None
    while len(ids) < 300:
        p = {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 50}
        if tok: p['pageToken'] = tok
        rr = api('playlistItems', p)
        if rr.get('_err'): break
        ids += [x['contentDetails']['videoId'] for x in rr.get('items', [])]
        tok = rr.get('nextPageToken')
        if not tok: break
    vh, dates, views, sp, pv = {}, [], [], 0, 0
    for i in range(0, len(ids), 50):
        rr = api('videos', {'part': 'snippet,statistics', 'id': ','.join(ids[i:i+50])})
        for x in rr.get('items', []):
            t = x['snippet']['title']
            d = x['snippet'].get('description') or ''
            for k, v in contacts(d).items(): vh.setdefault(k, []).extend(v)
            dates.append(x['snippet']['publishedAt'][:10])
            views.append(int(x['statistics'].get('viewCount', 0) or 0))
            if SPOIL.search(t): sp += 1
            if PREVIEW.search(t): pv += 1
            if DUNE.search(t): c.setdefault('_dune2', []).append(t)
    n = len(dates)
    recent = [d for d in dates if d >= str(datetime.date.today() - datetime.timedelta(days=90))]
    last = max(dates) if dates else ''
    vh_sorted = sorted(vh.items(), key=lambda x: -len(x[1]))
    c.update({'q_dune_hit': q_hit, 'chan_contact': {k: v[0] for k, v in ch_hits.items()},
              'video_contact': {k: v[0] for k, v in vh_sorted[:5]},
              'video_contact_n': {k: len(v) for k, v in vh_sorted[:5]},
              'total_scanned': len(ids), 'last': last, 'recent90': len(recent),
              'mean': int(sum(views)/len(views)) if views else 0,
              'median': int(statistics.median(views)) if views else 0,
              'spoil': sp, 'preview': pv, 'spoil_pct': round(sp*100/n) if n else 0,
              'preview_pct': round(pv*100/n) if n else 0})
    out.append(c)
    print('=' * 76)
    print('%-32s subs %-7s 分%.0f' % (c['title'][:32], c['subs'], c['score']))
    print('  主页q=듄 %d | 标题扫描沙丘 %d | 最近 %s | 90天 %d 条 | 均播 %d | 中位 %d' % (
        len(q_hit), len(c.get('_dune2', [])), last, len(recent), c['mean'], c['median']))
    print('  形态：결말포함类 %d%% ／ 前瞻分析类 %d%%' % (c['spoil_pct'], c['preview_pct']))
    print('  频道简介联系:', list(ch_hits.keys()) or '无')
    print('  视频简介联系:', vh_sorted[:3] or '无')
OUTF = sys.argv[2] if len(sys.argv) > 2 else 'df_s4.json'
json.dump(out, open(OUTF, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('\n已写入 %s，共 %d 个' % (OUTF, len(out)))
