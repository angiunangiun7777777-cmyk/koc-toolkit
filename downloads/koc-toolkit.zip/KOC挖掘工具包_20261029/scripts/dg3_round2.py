# -*- coding: utf-8 -*-
"""第二轮召回：换一批具体游戏名，继续扩游戏线池子（同样排除全部历史频道）。"""
import json, re, time, urllib.parse, urllib.request, statistics

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
EX = json.load(open('exclude_pool_raw.json', encoding='utf-8'))
EX_IDS = set(EX['ids']); EX_T = set(EX['titles'])
# 加上第一轮已经入围/淘汰的，避免重复
for f in ('dg2_s1.json',):
    try:
        for c in json.load(open(f, encoding='utf-8')):
            EX_IDS.add(c['cid']); EX_T.add(c['title'])
    except Exception:
        pass

W = ['원스휴먼', '선즈 오브 더 포레스트', '어바이오틱 팩터', '아크 서바이벌 어센디드',
     '발헤임 기지', '팰월드 기지', '이카루스 게임', '노맨즈스카이', '프로스트펑크 2',
     '좀보이드 멀티', '생존 게임 신작', '스팀 신작 게임 추천', '오픈월드 게임 추천',
     'PS5 게임 추천', '협동 게임 추천', '좀비 생존 게임', '기지 만들기 게임',
     '건축 게임 추천', '우주 생존 게임', '해저 생존 게임']
SH = ['원스휴먼', '발헤임 기지', '생존 게임 신작', '오픈월드 게임 추천', '좀비 생존 게임',
      'PS5 게임 추천', '기지 만들기 게임', '협동 게임 추천']

DUNE = re.compile(r'듄|dune|아라키스|메시아|스파이스\s*워즈|폴\s*아트레이데스|어웨이크닝', re.I)
MOBILE = re.compile(r'모바일|구글\s*플레이|앱\s*스토어|앱스토어|안드로이드|아이폰|원스토어', re.I)
SURV = re.compile(r'생존|크래프트|제작|기지|건설|건축|채집|사냥|자원|배고픔|목마름|'
                  r'발헤임|아크|러스트|코난|엔슈라우드|인슈라|팰월드|좀보이드|서브노티카|그라운디드|'
                  r'그린\s*헬|세븐\s*데이즈|데이즈|스컴|프로스트펑크|포레스트|원스휴먼|이카루스|'
                  r'노맨즈|어바이오틱|팰리아', re.I)
GUIDE = re.compile(r'공략|가이드|팁|초보|강좌|위키|정보|정리|방법|총정리|꿀팁|시작\s*법|플레이\s*법', re.I)
DESERT = re.compile(r'사막|포스트\s*아포칼립스|황무지|폐허|종말|멸망|모래', re.I)


def api(path, params, retry=4):
    params = dict(params); params['key'] = API_KEY
    url = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try:
            return json.load(urllib.request.urlopen(url, timeout=30))
        except Exception as e:
            if i == retry - 1:
                return {'_err': str(e)}
            time.sleep(2)


chans = {}
def recall(words, shorts=False):
    for w in words:
        p = {'part': 'snippet', 'type': 'video', 'q': w, 'maxResults': 50,
             'regionCode': 'KR', 'relevanceLanguage': 'ko'}
        if shorts:
            p['videoDuration'] = 'short'
        r = api('search', p)
        if r.get('_err'):
            print('  !!', w, r['_err'][:50]); continue
        g = 0
        for x in r.get('items', []):
            cid = x['snippet']['channelId']
            if cid in EX_IDS or x['snippet']['channelTitle'] in EX_T:
                continue
            chans.setdefault(cid, {'cid': cid, 'title': x['snippet']['channelTitle'], 'qs': []})
            if w not in chans[cid]['qs']:
                chans[cid]['qs'].append(w); g += 1
        print('  %-26s 新 %d' % (w, g))


print('=== 第二轮 常规 ==='); recall(W)
print('=== 第二轮 Shorts ==='); recall(SH, shorts=True)
print('去重后新频道 %d' % len(chans))
ids = list(chans.keys())
prof = []
for i in range(0, len(ids), 50):
    r = api('channels', {'part': 'snippet,statistics', 'id': ','.join(ids[i:i + 50])})
    for x in r.get('items', []):
        s, st = x['snippet'], x['statistics']
        subs = 0 if st.get('hiddenSubscriberCount') else int(st.get('subscriberCount', 0) or 0)
        c = chans[x['id']]
        c.update({'subs': subs, 'country': s.get('country') or '', 'customUrl': s.get('customUrl') or '',
                  'desc': s.get('description') or '', 'videos': int(st.get('videoCount', 0) or 0)})
        if c['country'] == 'KR' and 1000 <= subs <= 50000:
            prof.append(c)
json.dump(prof, open('dg3_s2.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('韩国 + 1k~5w：%d' % len(prof))

out = []
for n, c in enumerate(prof, 1):
    d = api('channels', {'part': 'contentDetails', 'id': c['cid']})
    if d.get('_err') or not d.get('items'):
        continue
    pl = d['items'][0]['contentDetails']['relatedPlaylists']['uploads']
    vid, tok = [], None
    while len(vid) < 150:
        p = {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 50}
        if tok: p['pageToken'] = tok
        r = api('playlistItems', p)
        if r.get('_err'): break
        vid += [x['contentDetails']['videoId'] for x in r.get('items', [])]
        tok = r.get('nextPageToken')
        if not tok: break
    titles, views, dh = [], [], []
    for i in range(0, len(vid), 50):
        r = api('videos', {'part': 'snippet,statistics', 'id': ','.join(vid[i:i + 50])})
        for x in r.get('items', []):
            t = x['snippet']['title']; titles.append(t)
            views.append(int(x['statistics'].get('viewCount', 0) or 0))
            if DUNE.search(t): dh.append(t)
    if len(titles) < 8: continue
    nt = len(titles)
    mob = sum(1 for t in titles if MOBILE.search(t))
    sv = sum(1 for t in titles if SURV.search(t))
    gd = sum(1 for t in titles if GUIDE.search(t))
    ds = sum(1 for t in titles if DESERT.search(t))
    med = int(statistics.median(views)) if views else 0
    gate = 0 if mob / nt > 0.25 else 1
    sc = sv / nt * 45 + gd / nt * 20 + ds / nt * 15 + (0 if not gate else 0)
    c.update({'n_titles': nt, 'sv': sv, 'gd': gd, 'ds': ds, 'mob': mob, 'median': med,
              'gate': gate, 'score': round(sc, 1), 'n_dune': len(dh), 'dune_hit': dh[:5],
              'sample': titles[:12]})
    out.append(c)
    print('%3d %-30s subs %-7s 生存%3d%% 攻略%3d%% 中位%-8s 沙丘%d 分%.0f' % (
        n, c['title'][:30], c['subs'], sv * 100 // nt, gd * 100 // nt, med, len(dh), sc))
out.sort(key=lambda x: -x['score'])
json.dump(out, open('dg3_s3.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('\n第二轮完成，有效 %d 个' % len(out))
