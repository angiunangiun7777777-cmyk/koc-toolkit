# -*- coding: utf-8 -*-
"""从打分结果里挑出要深挖的候选，避免一次性把几百个频道全丢给下一步烧配额。

用法：
    python3 pick_top.py <scored.json> <输出.json> [前N名=40] [最低分=0]

只保留 gate=1（硬门槛通过）的频道，按转化分从高到低取前 N 个。
"""
import json, sys

src = sys.argv[1]
dst = sys.argv[2]
N = int(sys.argv[3]) if len(sys.argv) > 3 else 40
MINS = float(sys.argv[4]) if len(sys.argv) > 4 else 0

d = json.load(open(src, encoding='utf-8'))
before = len(d)
d = [c for c in d if c.get('gate', 1) == 1]
gated = len(d)
d = [c for c in d if (c.get('score') or 0) >= MINS]
d.sort(key=lambda c: -(c.get('score') or 0))
d = d[:N]

json.dump(d, open(dst, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('输入 %d → 过门槛 %d → 取前 %d 个（最低分 %s）→ %s' % (before, gated, len(d), MINS, dst))
for c in d[:5]:
    print('   %-22s 订阅 %7s  转化分 %s' % (c.get('title'), c.get('subs'), c.get('score')))
