# -*- coding: utf-8 -*-
"""检查 17 个频道的单游戏垂直度：第一游戏占比 + 历史换过几个游戏 + 换游戏时播放掉多少。"""
import json, re, time, urllib.parse, urllib.request, statistics

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
CAP = 200

# 游戏名 -> 标准名
GAMES = [
 (r'발헤임|valheim', '발헤임'),
 (r'아크|ARK\b|아크서바이벌|ASA', 'ARK'),
 (r'러스트|RUST|rust', 'Rust'),
 (r'그린\s*헬|그린헬|GREEN HELL', 'Green Hell'),
 (r'서브노티카|Subnautica', '서브노티카'),
 (r'그라운디드|Grounded', 'Grounded'),
 (r'인슈라|엔슈라|Enshrouded', 'Enshrouded'),
 (r'팰월드|Palworld', '팰월드'),
 (r'좀보이드|Zomboid', '僵尸毁灭工程'),
 (r'더\s*포레스트|The Forest|포레스트', '더 포레스트'),
 (r'프로스트펑크|Frostpunk', 'Frostpunk'),
 (r'붉은사막', '붉은사막'),
 (r'세븐\s*데이즈|7 Days', '세븐 데이즈'),
 (r'스컴|SCUM', 'SCUM'),
 (r'원스휴먼|Once Human', '원스휴먼'),
 (r'코난|Conan', '코난 엑자일'),
 (r'데이즈|DayZ', 'DayZ'),
 (r'이카루스|Icarus', '이카루스'),
 (r'노맨즈|No Man', '노맨즈스카이'),
 (r'마인크래프트|Minecraft|마크', 'Minecraft'),
 (r'어바이오틱', '어바이오틱 팩터'),
 (r'선즈\s*오브', '선즈 오브 더 포레스트'),
 (r'테라리아|Terraria', '테라리아'),
 (r'던전|디아블로|엘든|위쳐', '其他大作'),
 (r'배틀그라운드|배그|PUBG', '배그'),
 (r'오버워치|로스트아크|메이플|던파|로블록스', '其他网游'),
]


def api(path, params, retry=4):
    params = dict(params); params['key'] = API_KEY
    url = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try:
            return json.load(urllib.request.urlopen(url, timeout=30))
        except Exception as e:
            if i == retry - 1:
                return {'_err': str(e)}
            time.sleep(2)


D = json.load(open('dg2_s4.json', encoding='utf-8'))
out = []
for c in D:
    d = api('channels', {'part': 'contentDetails', 'id': c['cid']})
    if d.get('_err') or not d.get('items'):
        continue
    pl = d['items'][0]['contentDetails']['relatedPlaylists']['uploads']
    ids, tok = [], None
    while len(ids) < CAP:
        p = {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 50}
        if tok: p['pageToken'] = tok
        r = api('playlistItems', p)
        if r.get('_err'): break
        ids += [x['contentDetails']['videoId'] for x in r.get('items', [])]
        tok = r.get('nextPageToken')
        if not tok: break
    items = []
    for i in range(0, len(ids), 50):
        r = api('videos', {'part': 'snippet,statistics', 'id': ','.join(ids[i:i + 50])})
        for x in r.get('items', []):
            items.append((x['snippet']['title'], int(x['statistics'].get('viewCount', 0) or 0)))
    if len(items) < 8: continue
    cnt, bygame = {}, {}
    for t, v in items:
        g = None
        for pat, name in GAMES:
            if re.search(pat, t, re.I):
                g = name; break
        cnt[g or '未识别'] = cnt.get(g or '未识别', 0) + 1
        bygame.setdefault(g or '未识别', []).append(v)
    n = len(items)
    rank = sorted(cnt.items(), key=lambda x: -x[1])
    top, topn = rank[0]
    conc = topn * 100 // n
    top_views = bygame.get(top, [])
    other = [v for g, vs in bygame.items() if g != top for v in vs]
    med_top = int(statistics.median(top_views)) if top_views else 0
    med_oth = int(statistics.median(other)) if other else 0
    drop = round((1 - med_oth / med_top) * 100) if (med_top and med_oth) else None
    c.update({'n': n, 'top_game': top, 'conc': conc, 'n_games': len([g for g in cnt if g != '未识别']),
              'rank': rank[:4], 'med_top': med_top, 'med_other': med_oth, 'drop': drop})
    out.append(c)
    print('%-22s 视频%-4d 第一游戏 %-14s 占%3d%% 识别到%2d款游戏  中位 主%7s/他%7s 掉%s%%' % (
        c['title'][:22], n, top[:14], conc, len([g for g in cnt if g != '未识别']),
        med_top, med_oth, drop if drop is not None else '-'))
    print('      分布:', ', '.join('%s %d' % (g[:12], k) for g, k in rank[:4]))

out.sort(key=lambda x: -x['conc'])
json.dump(out, open('vertical_check.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('\n已写入 vertical_check.json')
