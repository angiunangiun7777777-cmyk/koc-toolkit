# -*- coding: utf-8 -*-
"""通用出表：把任一条线跑完的最终 json 直接生成 HTML 表 + CSV。

用法：
    python3 make_table_auto.py <最终json> <游戏类|影评类> [输出文件名前缀]

例：
    python3 make_table_auto.py dg2_s4.json 游戏类 我的游戏线KOC
    python3 make_table_auto.py df_final16.json 影评类 我的影评线KOC

列格式固定 11 列（分类/用户名/平台/平台链接/粉丝量/视频内容类型/均播/活跃度/
邮箱/推荐理由/备注）。推荐理由与备注需要人工判断，脚本留空待填。
"""
import json, sys, html, csv, datetime, re

src = sys.argv[1]
CAT = sys.argv[2] if len(sys.argv) > 2 else '游戏类'
PRE = sys.argv[3] if len(sys.argv) > 3 else 'KOC名单_' + datetime.date.today().isoformat()

D = json.load(open(src, encoding='utf-8'))
D = [c for c in D if c.get('n_dune', 0) == 0]          # 沙丘零命中才进表
D.sort(key=lambda c: -(c.get('score') or 0))

TG = re.compile(r't\.me/[A-Za-z0-9_]+')
OK = re.compile(r'open\.kakao\.com/\S+|pf\.kakao\.com/[A-Za-z0-9_]+')


def pct(a, b):
    b = b or 1
    return int(100.0 * (a or 0) / b)


def contact(c):
    """视频简介里的联系方式优先（更可能是当前在用），频道简介兜底。"""
    v = c.get('video_contact') or {}
    ch = c.get('chan_contact') or {}
    em = [k for k in v if '@' in k] or [k for k in ch if '@' in k]
    alt = []
    for src_dict in (v, ch):
        for k in src_dict:
            if TG.search(k) or OK.search(k):
                alt.append(k)
    if not em:
        if alt:
            return '非邮箱渠道：' + alt[0]
        return '未公开（只能站内联系）'
    s = em[0]
    if len(set(em)) > 1:
        s += '（另见 %s，需按最近视频判断哪个在用）' % em[1]
    return s


def content_type(c):
    n = c.get('n_titles') or 1
    if CAT.startswith('影评'):
        sp, pv = c.get('spoil_pct') or 0, c.get('preview_pct') or 0
        th, ot = c.get('theater_pct') or 0, c.get('ott_pct') or 0
        form = '全剧透解说型' if sp >= 50 else ('前瞻/分析型' if pv >= 30 else '混合型')
        aud = '影院向观众' if th >= ot else 'OTT 向观众'
        return [('类型', form), ('形态占比', '剧透解说 %d%%｜前瞻分析 %d%%' % (sp, pv)),
                ('受众', aud), ('渠道倾向', '影院 %d%%｜OTT %d%%' % (th, ot))]
    pc, mob = pct(c.get('pc'), n), pct(c.get('mob'), n)
    sv, gd = pct(c.get('sv'), n), pct(c.get('gd'), n)
    style = '攻略/百科型' if gd >= 20 else ('生存建造实况' if sv >= 30 else '综合游戏实况')
    aud = 'PC/主机核心玩家' if pc >= mob else '手游休闲玩家'
    return [('类型', style), ('平台占比', 'PC/主机 %d%%｜手游 %d%%' % (pc, mob)),
            ('受众', aud), ('视频风格', '生存建造 %d%%｜攻略向 %d%%' % (sv, gd))]


def fmt(n):
    n = int(n or 0)
    return '{:,}'.format(n)


rows = []
for c in D:
    n = c.get('n_titles') or 1
    mean = c.get('mean') or (c.get('total_views', 0) // max(c.get('videos') or 1, 1))
    act = '最近更新 %s｜近90天 %s 条' % (c.get('last') or '—', c.get('recent90') or 0)
    rows.append({
        '分类': CAT,
        '用户名': c.get('title') or '',
        '平台': 'YouTube',
        '平台链接': 'https://www.youtube.com/channel/%s' % c.get('cid', ''),
        '粉丝量': fmt(c.get('subs')),
        '视频内容类型': content_type(c),
        '均播': fmt(mean),
        '活跃度': act,
        '邮箱': contact(c),
        '推荐理由': '',
        '备注': '转化分 %s｜样本 %d 条｜沙丘命中 %d' % (c.get('score'), n, c.get('n_dune') or 0),
    })

COLS = ['分类', '用户名', '平台', '平台链接', '粉丝量', '视频内容类型', '均播', '活跃度',
        '邮箱', '推荐理由', '备注']

# ---------- CSV ----------
with open(PRE + '.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.writer(f)
    w.writerow(COLS)
    for r in rows:
        w.writerow([' | '.join('%s:%s' % (k, v) for k, v in r['视频内容类型'])
                    if k == '视频内容类型' else r[k] for k in COLS])

# ---------- HTML ----------
def cell(v):
    if isinstance(v, list):
        return '<br>'.join('<b>%s</b>：%s' % (html.escape(k), html.escape(str(x)))
                           for k, x in v)
    return html.escape(str(v))


tds = []
for r in rows:
    t = '<tr>' + ''.join('<td class="c-%s">%s</td>' % (k, cell(r[k])) for k in COLS) + '</tr>'
    if r['平台链接']:
        t = t.replace('>%s</td>' % r['平台链接'],
                      '><a href="%s" target="_blank">频道主页</a></td>' % r['平台链接'])
    tds.append(t)

HTML = """<!doctype html><meta charset="utf-8"><title>%s</title>
<style>
body{font-family:-apple-system,"PingFang SC","Malgun Gothic",sans-serif;background:#f6f7f9;color:#1f2328;margin:0;padding:24px}
h1{font-size:20px;margin:0 0 6px}
.sub{color:#5b6470;font-size:13px;margin-bottom:16px}
table{border-collapse:collapse;width:100%%;background:#fff;font-size:13px;box-shadow:0 1px 3px rgba(0,0,0,.08)}
th{background:#eef1f5;border:1px solid #d8dee6;padding:9px 10px;text-align:left;white-space:nowrap;font-size:12px;color:#333}
td{border:1px solid #e3e7ec;padding:9px 10px;vertical-align:top;line-height:1.6}
tr:nth-child(even) td{background:#fafbfc}
.c-用户名{font-weight:600;white-space:nowrap}
.c-粉丝量,.c-均播{white-space:nowrap;text-align:right;font-variant-numeric:tabular-nums}
.c-推荐理由,.c-备注{color:#8a919b}
a{color:#1a6fd4;text-decoration:none}
</style>
<h1>%s</h1>
<div class="sub">共 %d 个候选（沙丘零命中）｜数据来源：YouTube Data API v3｜生成时间 %s｜
推荐理由与备注需人工补充</div>
<table><thead><tr>%s</tr></thead><tbody>%s</tbody></table>
""" % (html.escape(PRE), html.escape(PRE), len(rows),
       datetime.datetime.now().strftime('%Y-%m-%d %H:%M'),
       ''.join('<th>%s</th>' % c for c in COLS), '\n'.join(tds))

open(PRE + '.html', 'w', encoding='utf-8').write(HTML)
print('已生成 %s.html 和 %s.csv，共 %d 行' % (PRE, PRE, len(rows)))
