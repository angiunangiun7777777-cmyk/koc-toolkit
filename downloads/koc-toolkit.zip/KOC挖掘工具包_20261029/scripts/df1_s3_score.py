# -*- coding: utf-8 -*-
"""影评线 S3：拉近 200 条视频，按「转化为沙丘 3 电影观众」打分 + 沙丘两道排查。"""
import json, re, time, urllib.parse, urllib.request, statistics

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
CAP = 200

DUNE = re.compile(r'듄|dune|아라키스|메시아|스파이스\s*워즈|폴\s*아트레이데스|어웨이크닝|사막\s*행성', re.I)
FILM = re.compile(r'영화|극장|개봉| 예매|OTT|넷플릭스|쿠팡플레이|왓챠|디즈니', re.I)
# 决策向：观众是来「决定看什么」的
DECIDE = re.compile(r'리뷰|추천|결말|해석|명작|볼만한|볼\s*만한|재밌는|재미있는|순위|TOP\s*\d|\bTOP\b|'
                    r'정주행|후기|평점|쿠키|리뷰어|감상|명대사|숨은|모음|총정리|베스트|꼭\s*봐', re.I)
# 必看榜单/盘点：离购票最近
LISTP = re.compile(r'명작|TOP\s*\d|\bTOP\b|순위|추천\s*\d|모음|총정리|리스트|베스트|꼭\s*봐|인생\s*영화|'
                   r'명작\s*영화|개봉\s*예정|이번\s*주|신작', re.I)
# 科幻史诗大场面（沙丘 3 调性）
SCIFI = re.compile(r'SF|공상\s*과학|우주|미래|디스토피아|포스트\s*아포칼립스|블록버스터|대서사시|'
                   r'행성|사막|외계|로봇|인공지능|타임\s*루프|타임\s*슬립|에픽|판타지|전쟁|'
                   r'인터스텔라|블레이드\s*러너|매드맥스|스타워즈|아바타|매트릭스|프로메테우스|'
                   r'컨택트|그래비티|테넷|오펜하이머|듄', re.I)
# 反向：韩剧/综艺/日常
NOISE = re.compile(r'드라마|예능|아이돌|케이팝|K-?POP|먹방|브이로그|일상|여행|쿡방|'
                   r'애니|애니메이션|웹툰|만화', re.I)


def api(path, params, retry=4):
    params = dict(params); params['key'] = API_KEY
    url = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try:
            return json.load(urllib.request.urlopen(url, timeout=30))
        except Exception as e:
            if i == retry - 1: return {'_err': str(e)}
            time.sleep(2)


cands = json.load(open('df1_s2.json', encoding='utf-8'))
out = []
for n, c in enumerate(cands, 1):
    d = api('channels', {'part': 'contentDetails', 'id': c['cid']})
    if d.get('_err') or not d.get('items'): continue
    pl = d['items'][0]['contentDetails']['relatedPlaylists']['uploads']
    ids, tok = [], None
    while len(ids) < CAP:
        p = {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 50}
        if tok: p['pageToken'] = tok
        r = api('playlistItems', p)
        if r.get('_err'): break
        ids += [x['contentDetails']['videoId'] for x in r.get('items', [])]
        tok = r.get('nextPageToken')
        if not tok: break
    titles, views, dh = [], [], []
    for i in range(0, len(ids), 50):
        r = api('videos', {'part': 'snippet,statistics', 'id': ','.join(ids[i:i+50])})
        for x in r.get('items', []):
            t = x['snippet']['title']; titles.append(t)
            views.append(int(x['statistics'].get('viewCount', 0) or 0))
            if DUNE.search(t): dh.append(t)
    if len(titles) < 8: continue
    nt = len(titles)
    f = sum(1 for t in titles if FILM.search(t))
    dc = sum(1 for t in titles if DECIDE.search(t))
    ls = sum(1 for t in titles if LISTP.search(t))
    sf = sum(1 for t in titles if SCIFI.search(t))
    nz = sum(1 for t in titles if NOISE.search(t))
    med = int(statistics.median(views)) if views else 0
    mean = int(sum(views) / len(views)) if views else 0
    # gate：必须真是电影号（영화 类词 >=25%）且不是韩剧/综艺号
    gate = 1 if (f / nt >= 0.25 and nz / nt <= 0.40) else 0
    score = (dc / nt * 35) + (ls / nt * 25) + (sf / nt * 30) + (f / nt * 10)
    if not gate: score -= 30
    c.update({'n_titles': nt, 'film': f, 'decide': dc, 'list': ls, 'scifi': sf, 'noise': nz,
              'median': med, 'mean': mean, 'gate': gate, 'score': round(score, 1),
              'n_dune': len(dh), 'dune_hit': dh[:5], 'sample': titles[:12]})
    out.append(c)
    print('%3d %-30s subs %-7s 电影%3d%% 决策%3d%% 榜单%3d%% 科幻%3d%% 噪声%3d%% 沙丘%d 均播%-8s 分%.0f%s' % (
        n, c['title'][:30], c['subs'], f*100//nt, dc*100//nt, ls*100//nt, sf*100//nt,
        nz*100//nt, len(dh), mean, score, '' if gate else '  [非电影号]'))

out.sort(key=lambda x: -x['score'])
json.dump(out, open('df1_s3_scored.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('\nS3 完成，有效 %d 个' % len(out))
