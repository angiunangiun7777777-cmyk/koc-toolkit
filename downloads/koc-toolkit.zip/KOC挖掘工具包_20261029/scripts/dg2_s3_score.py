# -*- coding: utf-8 -*-
"""S3：对 125 个候选拉近期视频，按「转化为沙丘觉醒玩家」的三条判据打分 + 沙丘零命中排查。"""
import json, re, time, urllib.parse, urllib.request, statistics

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
CAP = 200

DUNE = re.compile(r'듄|dune|아라키스|메시아|스파이스\s*워즈|폴\s*아트레이데스|어웨이크닝', re.I)
PC = re.compile(r'스팀|steam|\bPC\b|피시|PS5|플스|엑스박스|xbox|콘솔|플레이스테이션', re.I)
MOBILE = re.compile(r'모바일|구글\s*플레이|앱\s*스토어|앱스토어|안드로이드|아이폰|원스토어', re.I)
SURV = re.compile(r'생존|크래프트|제작|기지|건설|건축|채집|사냥|자원|배고픔|목마름|'
                  r'발헤임|아크|러스트|코난|엔슈라우드|팰월드|좀보이드|서브노티카|그라운디드|'
                  r'그린\s*헬|세븐\s*데이즈|데이즈|스컴|프로스트펑크|더\s*포레스트|발로그', re.I)
GUIDE = re.compile(r'공략|가이드|팁|초보|강좌|위키|정보|정리|방법|총정리|꿀팁|'
                   r'\b팩\b|시작\s*법|플레이\s*법', re.I)
DESERT = re.compile(r'사막|포스트\s*아포칼립스|황무지|폐허|종말|멸망|생존자|모래', re.I)


def api(path, params, retry=4):
    params = dict(params); params['key'] = API_KEY
    url = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try:
            return json.load(urllib.request.urlopen(url, timeout=30))
        except Exception as e:
            if i == retry - 1:
                return {'_err': str(e)}
            time.sleep(2)


cands = json.load(open('dg2_s2.json', encoding='utf-8'))
out = []
for n, c in enumerate(cands, 1):
    d = api('channels', {'part': 'contentDetails', 'id': c['cid']})
    if d.get('_err') or not d.get('items'):
        continue
    pl = d['items'][0]['contentDetails']['relatedPlaylists']['uploads']
    ids, tok = [], None
    while len(ids) < CAP:
        p = {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 50}
        if tok:
            p['pageToken'] = tok
        r = api('playlistItems', p)
        if r.get('_err'):
            break
        ids += [x['contentDetails']['videoId'] for x in r.get('items', [])]
        tok = r.get('nextPageToken')
        if not tok:
            break
    titles, views, dune_hit = [], [], []
    for i in range(0, len(ids), 50):
        r = api('videos', {'part': 'snippet,statistics', 'id': ','.join(ids[i:i + 50])})
        for x in r.get('items', []):
            t = x['snippet']['title']
            titles.append(t)
            views.append(int(x['statistics'].get('viewCount', 0) or 0))
            if DUNE.search(t):
                dune_hit.append(t)
    if len(titles) < 8:
        continue
    n_t = len(titles)
    pc = sum(1 for t in titles if PC.search(t))
    mob = sum(1 for t in titles if MOBILE.search(t))
    sv = sum(1 for t in titles if SURV.search(t))
    gd = sum(1 for t in titles if GUIDE.search(t))
    ds = sum(1 for t in titles if DESERT.search(t))
    med = int(statistics.median(views)) if views else 0
    # 转化分：平台对了才谈转化；生存建造是核心；攻略型加分；沙漠废土加分；手游占比扣分
    gate = 0 if mob / n_t > 0.25 else 1
    score = (sv / n_t * 45) + (gd / n_t * 20) + (ds / n_t * 15) + (pc / n_t * 20)
    if not gate:
        score -= 25
    c.update({'n_titles': n_t, 'pc': pc, 'mob': mob, 'sv': sv, 'gd': gd, 'ds': ds,
              'median': med, 'gate': gate, 'score': round(score, 1),
              'dune_hit': dune_hit[:5], 'n_dune': len(dune_hit),
              'sample': titles[:12]})
    out.append(c)
    print('%3d %-32s subs %-7s 生存%3d%% 攻略%3d%% PC%3d%% 手游%3d%% 沙丘%d 中位%-8s 分%.0f%s' % (
        n, c['title'][:32], c['subs'], sv * 100 // n_t, gd * 100 // n_t, pc * 100 // n_t,
        mob * 100 // n_t, len(dune_hit), med, score, '  [手游出局]' if not gate else ''))

out.sort(key=lambda x: -x['score'])
json.dump(out, open('dg2_s3_scored.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('\nS3 完成，有效 %d 个，已写入 dg2_s3_scored.json' % len(out))
