# -*- coding: utf-8 -*-
"""① 确认 똠냥이 两个邮箱哪个在用 ② 对无联系方式的频道做无条件邮箱扫描 + about 页。"""
import json, re, time, urllib.parse, urllib.request

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
MAIL = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')
UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36'

def api(path, params, retry=3):
    params = dict(params); params['key'] = API_KEY
    u = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try: return json.load(urllib.request.urlopen(u, timeout=25))
        except Exception as e:
            if i == retry-1: return {'_err': str(e)}
            time.sleep(1.5)

D = {c['title']: c for c in json.load(open('df_final16.json', encoding='utf-8'))}

print('### ① 똠냥이 最近 12 条视频里出现的邮箱')
c = D['똠냥이']
pl = api('channels', {'part': 'contentDetails', 'id': c['cid']})['items'][0]['contentDetails']['relatedPlaylists']['uploads']
ids, tok = [], None
while len(ids) < 40:
    p = {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 50}
    if tok: p['pageToken'] = tok
    r = api('playlistItems', p); ids += [x['contentDetails']['videoId'] for x in r.get('items', [])]
    tok = r.get('nextPageToken')
    if not tok: break
r = api('videos', {'part': 'snippet', 'id': ','.join(ids[:12])})
for x in r.get('items', [])[:12]:
    ds = x['snippet'].get('description') or ''
    print('   %s | %s' % (x['snippet']['publishedAt'][:10], sorted({m.group(0).lower() for m in MAIL.finditer(ds)}) or '-'))

print('\n### ② 无联系方式频道：无条件邮箱扫描 + about 页')
NONE = ['미니필름(Mini Film)','디쿠무비','무비픽업','카페, 시네마','S펀지 무비[SPONGE MOVIE]',
        '지금여기','비디오보는남자','영화한잔?','좋은아네','좋은아내','라라무비','무비영이']
res = {}
for t in NONE:
    c = D.get(t)
    if not c: continue
    pl = api('channels', {'part': 'contentDetails', 'id': c['cid']})['items'][0]['contentDetails']['relatedPlaylists']['uploads']
    ids, tok = [], None
    while len(ids) < 200:
        p = {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 50}
        if tok: p['pageToken'] = tok
        r = api('playlistItems', p)
        if r.get('_err'): break
        ids += [x['contentDetails']['videoId'] for x in r.get('items', [])]
        tok = r.get('nextPageToken')
        if not tok: break
    mails, links = {}, {}
    for i in range(0, len(ids), 50):
        r = api('videos', {'part': 'snippet', 'id': ','.join(ids[i:i+50])})
        for x in r.get('items', []):
            ds = x['snippet'].get('description') or ''
            for m in MAIL.finditer(ds): mails[m.group(0).lower()] = mails.get(m.group(0).lower(), 0) + 1
            for u in re.findall(r'https?://[^\s|)"\']+', ds):
                dm = urllib.parse.urlparse(u).netloc.lower().replace('www.', '')
                links[dm] = links.get(dm, 0) + 1
    # about 页
    ab = ''
    try:
        req = urllib.request.Request('https://www.youtube.com/channel/%s/about' % c['cid'],
                                     headers={'User-Agent': UA, 'Accept-Language': 'ko,en'})
        ab = urllib.request.urlopen(req, timeout=25).read().decode('utf-8', 'ignore')
    except Exception as e:
        ab = 'ERR'
    ab_mails = sorted({m.group(0).lower() for m in MAIL.finditer(ab)})
    print('  %-26s 视频邮箱:%-34s about页:%s' % (
        t[:26], (sorted(mails.items(), key=lambda x: -x[1])[:2] or '无'), (ab_mails[:2] or '无')))
    print('        高频外链:', sorted(links.items(), key=lambda x: -x[1])[:4] or '无')
    res[t] = {'mails': mails, 'links': sorted(links.items(), key=lambda x: -x[1])[:6], 'about': ab_mails}
json.dump(res, open('df_email_fix.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
