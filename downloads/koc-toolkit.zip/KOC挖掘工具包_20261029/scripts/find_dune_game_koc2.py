# -*- coding: utf-8 -*-
"""沙丘游戏线 KOC 新批次：排除所有历史已出现频道，按「PC/主机生存建造」转化潜力召回。"""
import json, re, time, urllib.parse, urllib.request, sys

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
EX = json.load(open('exclude_pool_raw.json', encoding='utf-8'))
EX_IDS = set(EX['ids'])
EX_T = set(EX['titles'])

# 具体游戏名（韩国有玩家盘的 PC/主机生存建造线）+ 真人会打的口语词
GAME = ['발헤임', '아크 서바이벌', '러스트 게임', '코난 엑자일', '엔슈라우드', '팰월드',
        '데이즈 게임', '프로젝트 좀보이드', '서브노티카', '그라운디드', '그린 헬',
        '세븐 데이즈 투 다이', '더 포레스트 게임', '스컴 게임', '프로스트펑크']
INTENT = ['생존게임 추천', '생존 게임 공략', '오픈월드 생존 게임', '사막 생존 게임',
          '기지 건설 게임', '스팀 생존게임', 'PS5 생존게임', 'PS5 오픈월드 게임 추천',
          '생존 게임 초보', '크래프팅 게임 추천', '포스트 아포칼립스 게임',
          '협동 생존 게임', '샌드박스 생존 게임', '콘솔 오픈월드 게임']
WORDS = GAME + INTENT
SHORTS = ['생존게임 추천', '발헤임', '아크 서바이벌', '러스트 게임', '오픈월드 생존 게임',
          'PS5 생존게임', '기지 건설 게임', '사막 생존 게임']


def api(path, params, retry=4):
    params = dict(params); params['key'] = API_KEY
    url = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try:
            return json.load(urllib.request.urlopen(url, timeout=30))
        except Exception as e:
            if i == retry - 1:
                return {'_err': str(e)}
            time.sleep(2)


chans = {}
def recall(words, shorts=False):
    for w in words:
        p = {'part': 'snippet', 'type': 'video', 'q': w, 'maxResults': 50,
             'regionCode': 'KR', 'relevanceLanguage': 'ko'}
        if shorts:
            p['videoDuration'] = 'short'
        r = api('search', p)
        if r.get('_err'):
            print('  !! %s -> %s' % (w, r['_err'][:60])); continue
        got = 0
        for x in r.get('items', []):
            cid = x['snippet']['channelId']
            if cid in EX_IDS or x['snippet']['channelTitle'] in EX_T:
                continue
            c = chans.setdefault(cid, {'cid': cid, 'title': x['snippet']['channelTitle'],
                                       'qs': [], 'dur': set()})
            if w not in c['qs']:
                c['qs'].append(w)
            if shorts:
                c['dur'].add('short')
            else:
                c['dur'].add('long')
            got += 1
        print('  %-28s 新频道 %d' % (w, got))


print('=== S1 常规召回 ===')
recall(WORDS)
print('=== S1b Shorts 池 ===')
recall(SHORTS, shorts=True)

for c in chans.values():
    c['dur'] = sorted(c['dur'])
json.dump(list(chans.values()), open('dg2_s1.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('\nS1 完成，去重后新频道 %d 个' % len(chans))

# S2 画像：韩国 + 1k~5w
kw = [c['cid'] for c in chans.values()]
prof = []
for i in range(0, len(kw), 50):
    r = api('channels', {'part': 'snippet,statistics', 'id': ','.join(kw[i:i + 50])})
    for x in r.get('items', []):
        s, st = x['snippet'], x['statistics']
        subs = int(st.get('subscriberCount', 0) or 0)
        if st.get('hiddenSubscriberCount'):
            subs = 0
        c = chans[x['id']]
        c.update({'subs': subs, 'country': s.get('country') or '',
                  'customUrl': s.get('customUrl') or '', 'desc': s.get('description') or '',
                  'videos': int(st.get('videoCount', 0) or 0),
                  'total_views': int(st.get('viewCount', 0) or 0)})
        if c['country'] == 'KR' and 1000 <= subs <= 50000:
            prof.append(c)
json.dump(prof, open('dg2_s2.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('S2 完成，韩国 + 1k~5w 订阅：%d 个' % len(prof))
