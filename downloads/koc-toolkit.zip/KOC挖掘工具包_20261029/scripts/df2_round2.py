# -*- coding: utf-8 -*-
"""影评线第二轮：只打决策向/科幻/购票场景的词，挖真正的「决定买不买票」型号。"""
import json, re, time, urllib.parse, urllib.request, statistics

import os as _os
_KEY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'api_key.txt')
API_KEY = (open(_KEY_FILE, encoding='utf-8').read().strip() if _os.path.exists(_KEY_FILE)
       else _os.environ.get('YOUTUBE_API_KEY', '').strip())
if not API_KEY.startswith('AIza'):
    raise SystemExit('[缺少 API key] 请在工具包根目录的 api_key.txt 里填入你自己的 '
                     'YouTube Data API v3 密钥（以 AIza 开头），'
                     '或设置环境变量 YOUTUBE_API_KEY 后重跑。')
EX = json.load(open('exclude_pool_raw.json', encoding='utf-8'))
EX_IDS, EX_T = set(EX['ids']), set(EX['titles'])
for f in ('df1_s1.json',):
    try:
        for c in json.load(open(f, encoding='utf-8')):
            EX_IDS.add(c['cid']); EX_T.add(c['title'])
    except Exception: pass

W = ['크리스토퍼 놀란 영화', '놀란 영화 해석', '영화 세계관 설명', '원작 소설 영화화',
     '아이맥스 영화 추천', '개봉 예정 영화', '시사회 후기', '영화 분석',
     '명작 sf 영화', '우주 영화 추천', '미래 세계 영화', '영화관 가야하는 이유',
     '이번 주 개봉 영화', '영화 평점 리뷰', '영화 비하인드', '영화 음악 ost',
     '인터스텔라 리뷰', '블레이드 러너 해석', '아바타 세계관', '매드맥스 해석']
SH = ['명작 sf 영화', '영화 세계관', '놀란 영화', '개봉 예정 영화']

DUNE = re.compile(r'듄|dune|아라키스|메시아|스파이스\s*워즈|폴\s*아트레이데스|어웨이크닝|사막\s*행성', re.I)
FILM = re.compile(r'영화|극장|개봉|예매|OTT|넷플릭스|쿠팡플레이|왓챠|디즈니|IMAX|아이맥스', re.I)
DECIDE = re.compile(r'리뷰|추천|결말|해석|명작|볼만한|볼\s*만한|재밌는|재미있는|순위|TOP\s*\d|\bTOP\b|'
                    r'정주행|후기|평점|쿠키|감상|명대사|모음|총정리|베스트|꼭\s*봐|분석|리뷰어', re.I)
LISTP = re.compile(r'명작|TOP\s*\d|\bTOP\b|순위|모음|총정리|리스트|베스트|꼭\s*봐|인생\s*영화|'
                   r'개봉\s*예정|이번\s*주|신작|시사회', re.I)
SCIFI = re.compile(r'SF|공상\s*과학|우주|미래|디스토피아|포스트\s*아포칼립스|블록버스터|대서사시|'
                   r'행성|사막|외계|로봇|인공지능|타임\s*루프|에픽|판타지|'
                   r'인터스텔라|블레이드\s*러너|매드맥스|스타워즈|아바타|매트릭스|프로메테우스|'
                   r'컨택트|그래비티|테넷|오펜하이머|놀란|세계관', re.I)
NOISE = re.compile(r'드라마|예능|아이돌|케이팝|K-?POP|먹방|브이로그|일상|여행|쿡방', re.I)


def api(path, params, retry=4):
    params = dict(params); params['key'] = API_KEY
    url = 'https://www.googleapis.com/youtube/v3/%s?%s' % (path, urllib.parse.urlencode(params))
    for i in range(retry):
        try:
            return json.load(urllib.request.urlopen(url, timeout=30))
        except Exception as e:
            if i == retry - 1: return {'_err': str(e)}
            time.sleep(2)


chans = {}
def recall(words, shorts=False):
    for w in words:
        p = {'part': 'snippet', 'type': 'video', 'q': w, 'maxResults': 50,
             'regionCode': 'KR', 'relevanceLanguage': 'ko'}
        if shorts: p['videoDuration'] = 'short'
        r = api('search', p)
        if r.get('_err'): print('  !!', w, r['_err'][:50]); continue
        g = 0
        for x in r.get('items', []):
            cid = x['snippet']['channelId']
            if cid in EX_IDS or x['snippet']['channelTitle'] in EX_T: continue
            chans.setdefault(cid, {'cid': cid, 'title': x['snippet']['channelTitle'], 'qs': []})
            if w not in chans[cid]['qs']: chans[cid]['qs'].append(w); g += 1
        print('  %-24s 新 %d' % (w, g))

print('=== 第二轮 常规 ==='); recall(W)
print('=== 第二轮 Shorts ==='); recall(SH, shorts=True)
print('去重后新频道 %d' % len(chans))
ids = list(chans.keys())
prof = []
for i in range(0, len(ids), 50):
    r = api('channels', {'part': 'snippet,statistics', 'id': ','.join(ids[i:i+50])})
    for x in r.get('items', []):
        s, st = x['snippet'], x['statistics']
        subs = 0 if st.get('hiddenSubscriberCount') else int(st.get('subscriberCount', 0) or 0)
        c = chans[x['id']]
        c.update({'subs': subs, 'country': s.get('country') or '', 'customUrl': s.get('customUrl') or '',
                  'desc': s.get('description') or '', 'videos': int(st.get('videoCount', 0) or 0)})
        if c['country'] == 'KR' and 1000 <= subs <= 50000: prof.append(c)
json.dump(prof, open('df2_s2.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('韩国 + 1k~5w：%d' % len(prof))

out = []
for n, c in enumerate(prof, 1):
    d = api('channels', {'part': 'contentDetails', 'id': c['cid']})
    if d.get('_err') or not d.get('items'): continue
    pl = d['items'][0]['contentDetails']['relatedPlaylists']['uploads']
    vid, tok = [], None
    while len(vid) < 150:
        p = {'part': 'contentDetails', 'playlistId': pl, 'maxResults': 50}
        if tok: p['pageToken'] = tok
        r = api('playlistItems', p)
        if r.get('_err'): break
        vid += [x['contentDetails']['videoId'] for x in r.get('items', [])]
        tok = r.get('nextPageToken')
        if not tok: break
    titles, views, dh = [], [], []
    for i in range(0, len(vid), 50):
        r = api('videos', {'part': 'snippet,statistics', 'id': ','.join(vid[i:i+50])})
        for x in r.get('items', []):
            t = x['snippet']['title']; titles.append(t)
            views.append(int(x['statistics'].get('viewCount', 0) or 0))
            if DUNE.search(t): dh.append(t)
    if len(titles) < 8: continue
    nt = len(titles)
    f = sum(1 for t in titles if FILM.search(t))
    dc = sum(1 for t in titles if DECIDE.search(t))
    ls = sum(1 for t in titles if LISTP.search(t))
    sf = sum(1 for t in titles if SCIFI.search(t))
    nz = sum(1 for t in titles if NOISE.search(t))
    med = int(statistics.median(views)) if views else 0
    mean = int(sum(views) / len(views)) if views else 0
    gate = 1 if (f / nt >= 0.20 and nz / nt <= 0.45) else 0
    sc = dc/nt*35 + ls/nt*25 + sf/nt*30 + f/nt*10
    if not gate: sc -= 30
    c.update({'n_titles': nt, 'film': f, 'decide': dc, 'list': ls, 'scifi': sf, 'noise': nz,
              'median': med, 'mean': mean, 'gate': gate, 'score': round(sc, 1),
              'n_dune': len(dh), 'dune_hit': dh[:5], 'sample': titles[:12]})
    out.append(c)
    print('%3d %-28s subs %-7s 电影%3d%% 决策%3d%% 榜单%3d%% 科幻%3d%% 沙丘%d 均播%-8s 分%.0f' % (
        n, c['title'][:28], c['subs'], f*100//nt, dc*100//nt, ls*100//nt, sf*100//nt, len(dh), mean, sc))
out.sort(key=lambda x: -x['score'])
json.dump(out, open('df2_s3.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('\n第二轮完成，有效 %d 个' % len(out))
