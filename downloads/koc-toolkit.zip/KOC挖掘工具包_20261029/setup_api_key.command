#!/bin/bash
cd "$(dirname "$0")" || exit 1
echo "=============================================="
echo " YouTube Data API v3 密钥配置"
echo "=============================================="
echo ""
echo "还没有密钥？三步拿到："
echo "  1. 打开 https://console.cloud.google.com/"
echo "  2. 新建项目 -> API 和服务 -> 库 -> 搜 YouTube Data API v3 -> 启用"
echo "  3. 凭据 -> 创建凭据 -> API 密钥 -> 复制"
echo ""
if ! command -v python3 >/dev/null 2>&1; then
  echo "[错误] 没找到 python3，请先安装 Python 3（https://www.python.org/downloads/）"
  read -r -p "按回车退出..."
  exit 1
fi
read -r -p "请粘贴你的 API 密钥（直接回车则跳过）：" K
if [ -z "$K" ]; then
  echo "已跳过，未做修改。"
  read -r -p "按回车退出..."
  exit 0
fi
printf "%s" "$K" > api_key.txt
echo ""
echo "已写入 $(pwd)/api_key.txt"
echo "正在验证密钥是否可用..."
python3 - <<'PY'
import json, urllib.parse, urllib.request
k = open('api_key.txt', encoding='utf-8').read().strip()
url = ('https://www.googleapis.com/youtube/v3/search?part=snippet&type=video'
       '&q=test&maxResults=1&key=' + urllib.parse.quote(k))
try:
    d = json.load(urllib.request.urlopen(url, timeout=20))
    if 'items' in d:
        print('密钥可用，测试返回 %d 条结果。配置完成。' % len(d['items']))
    else:
        print('密钥可能有问题，返回内容：%s' % str(d)[:300])
except Exception as e:
    print('密钥不可用：%s' % e)
PY
echo ""
read -r -p "按回车退出..."
