#!/bin/bash
cd "$(dirname "$0")/scripts" || exit 1
echo "=============================================="
echo " 影视类 KOC 全流程（约 7 步，耗时看候选数量）"
echo "=============================================="
if ! command -v python3 >/dev/null 2>&1; then
  echo "[错误] 没找到 python3，请先安装 Python 3"
  read -r -p "按回车退出..."; exit 1
fi
if [ ! -f ../api_key.txt ] || grep -q "PASTE_YOUR" ../api_key.txt 2>/dev/null; then
  echo "[错误] 还没配置 API 密钥，请先双击 setup_api_key.command"
  read -r -p "按回车退出..."; exit 1
fi

echo ""
echo "[1/7] 第一轮召回（决策词 + 榜单词 + 同调性锚点片）"
python3 df1_find_movie_koc.py || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "[2/7] 第一轮打分"
python3 df1_s3_score.py || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "[3/7] 第二轮扩召回 + 打分"
python3 df2_round2.py || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "[4/7] 活跃度快筛（剔掉近 120 天没更新的）"
python3 df_active_scan.py || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "[5/7] 挑出前 30 名"
python3 pick_top.py df_alive.json df_picks.json 30 || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "[6/7] 排查目标 IP + 抓联系方式（分两批跑，避免一次跑太久）"
python3 - <<'PY'
import json
d = json.load(open('df_picks.json', encoding='utf-8'))
h = (len(d) + 1) // 2
json.dump(d[:h], open('df_picks_a.json', 'w', encoding='utf-8'), ensure_ascii=False)
json.dump(d[h:], open('df_picks_b.json', 'w', encoding='utf-8'), ensure_ascii=False)
print('   拆成两批：%d + %d' % (h, len(d) - h))
PY
python3 df_s4_contacts.py df_picks_a.json df_s4.json || { read -r -p "出错，按回车退出..."; exit 1; }
python3 df_s4_contacts.py df_picks_b.json df_s4b.json || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "[7/7] 影院向 vs OTT 向占比 + 出表"
python3 df_theater.py || { read -r -p "出错，按回车退出..."; exit 1; }
python3 make_table_auto.py df_final16.json 影评类 我的影视线KOC || { read -r -p "出错，按回车退出..."; exit 1; }

echo ""
echo "=============================================="
echo " 完成。成果在 scripts/ 目录："
echo "   我的影视线KOC.html  （双击用浏览器打开）"
echo "   我的影视线KOC.csv"
echo " 中间数据：df1_s3_scored.json / df_alive.json / df_s4.json / df_final16.json"
echo ""
echo " 别忘了人工做两件事："
echo "   1) 填推荐理由和备注（脚本留空了）"
echo "   2) 韩国影评号主流是全剧透解说，天然不导向购票，"
echo "      要用在上映前的 IP 认知铺垫，别指望直接带票房"
echo "=============================================="
open . 2>/dev/null
read -r -p "按回车退出..."
